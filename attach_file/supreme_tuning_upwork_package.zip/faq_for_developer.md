
T# Supreme Tuning – Developer FAQ

### Q: Do we use a real database?
A: No. JSON file used as database.

### Q: Are prices scraped?
A: No. Only HP/Nm. Prices entered by admin.

### Q: Are Stage 1+ and Stage 2+ different?
A: They start as copies of Stage 1 and 2. Client can adjust later.

### Q: Do we need DVX branding?
A: No. Never display DVX publicly.

### Q: Do we need login?
A: Yes, admin MUST be protected.

### Q: Do we need to deploy?
A: Yes — backend & frontend must run on staging/production.
